﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ROMEstimator : Page
{
    private ReadRomViewModel RomViewModel { get; set; }

    protected override void OnPreLoad(EventArgs e)
    {
        // Populate the IaaS Type Names before the UI loads so we don't overwrite user
        // data on postbacks
        List<IaaSIdAndName> iaaSTypeNames = Common.LoadIaaSTypes();
        if (dropdownIaaSType.Items.Count == 0)
        {
            foreach (var iaaSType in iaaSTypeNames)
            {
                dropdownIaaSType.Items.Add(new ListItem(iaaSType.Name, iaaSType.ID.ToString()));
            }
        }
        base.OnPreLoad(e);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        Guid romId;
        if (!Guid.TryParse(Page.ClientQueryString, out romId))
        {
            throw new Exception("No ROM ID specified in the query string.");
        }

        // Read the ROM from the database and populate the form
        RomestimatorDataLayer romestimatorDataLayer = new RomestimatorDataLayer();
        ObjectResult<ReadRom_Result> objectResult = romestimatorDataLayer.ReadRom(romId);
        RomViewModel = Common.FlattenRomFromDatabase(objectResult.ToList());
        RomViewModel.ID = romId;

        if (Page.IsPostBack == true)
        {
            // do not clear out any values
        }
        else
        {
            // Not a postback from the page - go ahead and load the ROM based on its GUID (id)           
            PopulateUI();
            if (CanProvideEstimate())
            {
                PopulateEstimateFromViewModel();
            }
        }
    }

    protected void dropdownNeedIaaS_SelectedIndexChanged(object sender, EventArgs e)
    {
        SyncIaaS();
        dropdownNeedIaaS.Focus();
        dropdownIaaSType.Focus();
    }

    protected void dropdownNumberOfIaaSEnvironments_SelectedIndexChanged(object sender, EventArgs e)
    {
        SyncEnvironmentCount();
        dropdownNumberOfIaaSEnvironments.Focus();
        Environment1Name.Focus();
    }

    protected void dropdownPaasNeeded_SelectedIndexChanged(object sender, EventArgs e)
    {
        SyncPaaS();
        dropdownPaasNeeded.Focus();
        txtPaasDbInstances.Focus();
    }

    protected void btnUpdateEstimate_Click(object sender, EventArgs e)
    {
        if (!SaveROM())
            return;
        if (!PopulateEstimate())
            return;
    }

    protected void btnSaveROM_Click(object sender, EventArgs e)
    {
        if (!SaveROM())
            return;
        // Also populate the estimate - the ROM may still be a WIP, but the sproc can handle this
        if (CanProvideEstimate())
        {
            if (!PopulateEstimate())
                return;
        }
    }

    protected void btnFinalizeROM_Click(object sender, EventArgs e)
    {
        if (!SaveROM())
            return;
        // Also populate the estimate
        if (!PopulateEstimate())
            return;
        // TODO: Now finalize the ROM - we want to provide some type of modal warning here
        var finalizeResults = Common.FinalizeRom(Page, RomViewModel);
        labelTotalOneTimeCost.Text = finalizeResults.OneTimeCost == null ?
            "N/A" :
            finalizeResults.OneTimeCost.Value.ToString("C", Common.Culture);
        labelSustainmentCostPerYear.Text = finalizeResults.SustainmentPerYear == null ?
            "N/A" :
            finalizeResults.SustainmentPerYear.Value.ToString("C", Common.Culture);
        // TODO: we may not have to redirect to get everything set to read-only
        Page.Response.Redirect(Page.Request.Url.AbsoluteUri);
    }

    #region Private Methods

    private void PopulateUI()
    {
        if (RomViewModel == null)
        {
            throw new Exception("Attempt to populate UI with no ROM information present");
        }

        txtURL.Text = Page.Request.Url.AbsoluteUri;
        this.Notes.Text = RomViewModel.Notes;
        this.VIPRID.Text = RomViewModel.VIPRID;
        this.VASI.Text = RomViewModel.VASI;
        this.ProjectName.Text = RomViewModel.ReadOnly ?
            (RomViewModel.ProjectName + " (Finalized, Read-Only)") :
            RomViewModel.ProjectName;
        this.dropdownNeedIaaS.SelectedValue = RomViewModel.IaaSNeeded ? "1" : "0";
        if (RomViewModel.IaaSType != null)
        {
            this.dropdownIaaSType.SelectedValue = RomViewModel.IaaSType.Value.ToString();
        }
        this.dropdownPaasNeeded.SelectedValue = RomViewModel.PaaSNeeded ? "1" : "0";
        this.dropdownSustainmentNeeded.SelectedValue =
                RomViewModel.SustainmentNeeded == true ? "1" : "0";
        this.dropdownInstancesHighlyAvailable.SelectedValue =
            (RomViewModel.InstancesHighlyAvailable != null &&
            RomViewModel.InstancesHighlyAvailable.Value == true) ? "1" : "0";
        this.txtPaasDbInstances.Text = RomViewModel.DatabaseInstanceCount.ToString();
        this.dropdownNumberOfIaaSEnvironments.SelectedValue = RomViewModel.IaaSEnvironmentCount == null ? "1" : RomViewModel.IaaSEnvironmentCount.Value.ToString();
        SyncIaaS();
        SyncPaaS();

        // If the ROM is finalized, we want to display the "stamped" pricing information and mark the entire form as read-only.
        if (RomViewModel.ReadOnly)
        {
            labelTotalOneTimeCost.Text = RomViewModel.QuotedOneTimePrice == null ?
                "N/A" :
                RomViewModel.QuotedOneTimePrice.Value.ToString("C", Common.Culture);

            labelSustainmentCostPerYear.Text = RomViewModel.QuotedSustainmentCost == null ?
                "N/A" :
                RomViewModel.QuotedSustainmentCost.Value.ToString("C", Common.Culture);

            MakeFormReadOnly();
        }
    }

    private void MakeFormReadOnly()
    {
        ProjectName.ReadOnly = true;
        txtEnvironment1Servers.ReadOnly = true;
        txtEnvironment2Servers.ReadOnly = true;
        txtEnvironment3Servers.ReadOnly = true;
        txtEnvironment4Servers.ReadOnly = true;
        txtEnvironment5Servers.ReadOnly = true;
        VIPRID.ReadOnly = true;
        VASI.ReadOnly = true;
        Notes.ReadOnly = true;
        Environment1Name.ReadOnly = true;
        Environment2Name.ReadOnly = true;
        Environment3Name.ReadOnly = true;
        Environment4Name.ReadOnly = true;
        Environment5Name.ReadOnly = true;
        Notes.BackColor = System.Drawing.Color.LightGray;
        VIPRID.BackColor = System.Drawing.Color.LightGray;
        VASI.BackColor = System.Drawing.Color.LightGray;
        ProjectName.BackColor = System.Drawing.Color.LightGray;
        txtPaasDbInstances.BackColor = System.Drawing.Color.LightGray;
        txtEnvironment1Servers.BackColor = System.Drawing.Color.LightGray;
        txtEnvironment2Servers.BackColor = System.Drawing.Color.LightGray;
        txtEnvironment3Servers.BackColor = System.Drawing.Color.LightGray;
        txtEnvironment4Servers.BackColor = System.Drawing.Color.LightGray;
        txtEnvironment5Servers.BackColor = System.Drawing.Color.LightGray;
        Environment1Name.BackColor = System.Drawing.Color.LightGray;
        Environment2Name.BackColor = System.Drawing.Color.LightGray;
        Environment3Name.BackColor = System.Drawing.Color.LightGray;
        Environment4Name.BackColor = System.Drawing.Color.LightGray;
        Environment5Name.BackColor = System.Drawing.Color.LightGray;
        txtPaasDbInstances.ReadOnly = true;
        dropdownIaaSType.Enabled = false;
        dropdownInstancesHighlyAvailable.Enabled = false;
        dropdownNeedIaaS.Enabled = false;
        dropdownNumberOfIaaSEnvironments.Enabled = false;
        dropdownPaasNeeded.Enabled = false;
        dropdownSustainmentNeeded.Enabled = false;
        btnFinalizeROM.Visible = false;
        btnSaveROM.Visible = false;
        btnUpdateEstimate.Visible = false;
        if (RomViewModel.DateFinalized != null)
        {
            labelLastSavedAt.Text = "";
            labelFinalizedDate.Text = "This ROM was Finalized and Marked as Read Only on " + RomViewModel.DateFinalized.Value.ToShortDateString();
            lblInstructions.Text = "Please save or print this page for future reference.<br/>";
            lblInstructions1.Text = "Use CTRL-P to Print to PDF or Save as PDF.<br/>";
            lblInstructions2.Text = "Please note that this ROM Estimate is a rough estimate and the numbers may run high.<br/>";

        }
    }

    private bool CanProvideEstimate()
    {
        if (RomViewModel.ReadOnly)
            return false;

        if (!string.IsNullOrEmpty(VIPRID.Text) || !string.IsNullOrEmpty(VASI.Text))
        {
            if (PerformValidation(false) == true)
                return true;
        }
        return false;
    }

    private void PopulateRomViewModelFromUI()
    {
        RomViewModel.ProjectName = this.ProjectName.Text;
        RomViewModel.PaaSNeeded = dropdownPaasNeeded.SelectedValue == "0" ? false : true;
        RomViewModel.IaaSNeeded = dropdownNeedIaaS.SelectedValue == "0" ? false : true;
        RomViewModel.SustainmentNeeded = dropdownSustainmentNeeded.SelectedValue == "0" ? false : true;
        RomViewModel.Notes = Notes.Text;
        RomViewModel.VIPRID = VIPRID.Text;
        RomViewModel.VASI = VASI.Text;
        if (!string.IsNullOrEmpty(RomViewModel.VIPRID) || !string.IsNullOrEmpty(RomViewModel.VASI))
        {
            labelRequireVIPRIDVASI.Visible = false;
        }
        if (RomViewModel.IaaSNeeded)
        {
            RomViewModel.IaaSEnvironmentCount = int.Parse(dropdownNumberOfIaaSEnvironments.SelectedValue);
            RomViewModel.IaaSType = int.Parse(dropdownIaaSType.SelectedValue);
            RomViewModel.Environments = new Environment[5];
            if (RomViewModel.IaaSEnvironmentCount.Value >= 1)
            {
                int serverCount = 0;
                if (!string.IsNullOrEmpty(txtEnvironment1Servers.Text) &&
                    !int.TryParse(txtEnvironment1Servers.Text, out serverCount))
                {
                    throw new Exception(
                        "Validation should have already caught the invalid value for number of servers, environment 1");
                }
                RomViewModel.Environments[0] = new Environment()
                {
                    Index = 1,
                    Name = Environment1Name.Text,
                    NumberOfServers = serverCount
                };
            }
            if (RomViewModel.IaaSEnvironmentCount.Value >= 2)
            {
                int serverCount = 0;
                if (!string.IsNullOrEmpty(txtEnvironment2Servers.Text) &&
                    !int.TryParse(txtEnvironment2Servers.Text, out serverCount))
                {
                    throw new Exception(
                         "Validation should have already caught the invalid value for number of servers, environment 2");
                }
                RomViewModel.Environments[1] = new Environment()
                {
                    Index = 2,
                    Name = Environment2Name.Text,
                    NumberOfServers = serverCount
                };
            }
            if (RomViewModel.IaaSEnvironmentCount.Value >= 3)
            {
                int serverCount = 0;
                if (!string.IsNullOrEmpty(txtEnvironment3Servers.Text) &&
                    !int.TryParse(txtEnvironment3Servers.Text, out serverCount))
                {
                    throw new Exception(
                        "Validation should have already caught the invalid value for number of servers, environment 3");
                }
                RomViewModel.Environments[2] = new Environment()
                {
                    Index = 3,
                    Name = Environment3Name.Text,
                    NumberOfServers = serverCount
                };
            }
            if (RomViewModel.IaaSEnvironmentCount.Value >= 4)
            {
                int serverCount = 0;
                if (!string.IsNullOrEmpty(txtEnvironment4Servers.Text) &&
                    !int.TryParse(txtEnvironment4Servers.Text, out serverCount))
                {
                    throw new Exception(
                        "Validation should have already caught the invalid value for number of servers, environment 4");
                }
                RomViewModel.Environments[3] = new Environment()
                {
                    Index = 4,
                    Name = Environment4Name.Text,
                    NumberOfServers = serverCount
                };
            }
            if (RomViewModel.IaaSEnvironmentCount.Value == 5)
            {
                int serverCount = 0;
                if (!string.IsNullOrEmpty(txtEnvironment5Servers.Text) &&
                    !int.TryParse(txtEnvironment5Servers.Text, out serverCount))
                {
                    throw new Exception(
                        "Validation should have already caught the invalid value for number of servers, environment 5");
                }
                RomViewModel.Environments[4] = new Environment()
                {
                    Index = 5,
                    Name = Environment5Name.Text,
                    NumberOfServers = serverCount
                };
            }
        }
        else
        {
            RomViewModel.IaaSEnvironmentCount = 0;
        }
        if (RomViewModel.PaaSNeeded)
        {
            int dbInstances = 0;
            if (int.TryParse(this.txtPaasDbInstances.Text, out dbInstances))
            {
                RomViewModel.DatabaseInstanceCount = dbInstances;
            }
            else
            {
                throw new Exception(
                    "Validation should have already caught the invalid value in PaaS number of databases");
            }
            RomViewModel.InstancesHighlyAvailable = this.dropdownInstancesHighlyAvailable.SelectedValue == "0" ? false : true;
        }
    }

    private bool ValidateCount(TextBox txtCount, Label labelValidationError, bool showVisually)
    {
        if (string.IsNullOrEmpty(txtCount.Text))
        {
            txtCount.Text = "1";
        }
        if (!string.IsNullOrEmpty(txtCount.Text) && !IsValidNumber(txtCount.Text))
        {
            if (showVisually)
            {
                labelValidationError.Visible = true;
                txtCount.Focus();
                Page.MaintainScrollPositionOnPostBack = false;
                Page.SetFocus(txtPaasDbInstances);
            }
            return false;
        }
        return true;
    }

    protected void dropdownSustainmentNeeded_SelectedIndexChanged(object sender, EventArgs e)
    {
        labelSustainmentCostPerYear.Text = "(Update Estimate)";
    }

    private bool PerformValidation(bool showVisually)
    {
        // First, clear any validation that may already be visible
        if (showVisually)
        {
            validationPaasDbInstances.Visible = false;
            validationMaxServersExceeded.Visible = false;
            validationIaaS1.Visible = false;
            validationIaaS2.Visible = false;
            validationIaaS3.Visible = false;
            validationIaaS4.Visible = false;
            validationIaaS5.Visible = false;
            validationNotes.Visible = false;
        }

        // We purposefully validate the form from bottom-most to top-most so we can set focus
        // at the first input control that contains an error without additional coding
        bool validationSucceeded = true;
        if (!string.IsNullOrEmpty(Notes.Text) && Notes.Text.Length > 1000)
        {
            validationSucceeded = false;
            if (showVisually)
            {
                validationNotes.Visible = true;
                Notes.Focus();
                Page.MaintainScrollPositionOnPostBack = false;
                Page.SetFocus(Notes);
            }
        }
        if (dropdownPaasNeeded.SelectedValue == "1")
        {
            if (!ValidateCount(txtPaasDbInstances, validationPaasDbInstances, showVisually))
            {
                validationSucceeded = false;
            }
        }
        if (dropdownNeedIaaS.SelectedValue == "1")
        {
            int environmentsNeeded = int.Parse(dropdownNumberOfIaaSEnvironments.SelectedValue);
            if (environmentsNeeded > 4)
            {
                if (!ValidateCount(txtEnvironment5Servers, validationIaaS5, showVisually))
                {
                    validationSucceeded = false;
                }
            }
            if (environmentsNeeded > 3)
            {
                if (!ValidateCount(txtEnvironment4Servers, validationIaaS4, showVisually))
                {
                    validationSucceeded = false;
                }
            }
            if (environmentsNeeded > 2)
            {
                if (!ValidateCount(txtEnvironment3Servers, validationIaaS3, showVisually))
                {
                    validationSucceeded = false;
                }
            }
            if (environmentsNeeded > 1)
            {
                if (!ValidateCount(txtEnvironment2Servers, validationIaaS2, showVisually))
                {
                    validationSucceeded = false;
                }
            }
            if (string.IsNullOrEmpty(txtEnvironment1Servers.Text))
            {
                txtEnvironment1Servers.Text = "1";
            }
            if (!string.IsNullOrEmpty(txtEnvironment1Servers.Text) && !IsValidNumber(txtEnvironment1Servers.Text))
            {
                if (!ValidateCount(txtEnvironment1Servers, validationIaaS1, showVisually))
                {
                    validationSucceeded = false;
                }
            }
            //// TODO: HEREHERE: This is a stop-gap measure until we get feedback on how to handle the case
            //// where the customer requests more than the maximum number of total servers listed for the
            //// "Extra Large" bucket as "max number of servers"
            //// This will be throw-away code once we receive an answer for how to handle this scenario
            //if (validationSucceeded)
            //{
            //    List<int> serversPerEnvironment = new List<int>();
            //    if (environmentsNeeded >= 5)
            //        serversPerEnvironment.Add(string.IsNullOrEmpty(txtEnvironment5Servers.Text) ? 0 : int.Parse(txtEnvironment5Servers.Text));
            //    if (environmentsNeeded >= 4)
            //        serversPerEnvironment.Add(string.IsNullOrEmpty(txtEnvironment4Servers.Text) ? 0 : int.Parse(txtEnvironment4Servers.Text));
            //    if (environmentsNeeded >= 3)
            //        serversPerEnvironment.Add(string.IsNullOrEmpty(txtEnvironment3Servers.Text) ? 0 : int.Parse(txtEnvironment3Servers.Text));
            //    if (environmentsNeeded >= 2)
            //        serversPerEnvironment.Add(string.IsNullOrEmpty(txtEnvironment2Servers.Text) ? 0 : int.Parse(txtEnvironment2Servers.Text));
            //    if (environmentsNeeded >= 1)
            //        serversPerEnvironment.Add(string.IsNullOrEmpty(txtEnvironment1Servers.Text) ? 0 : int.Parse(txtEnvironment1Servers.Text));
            //    int allowableMax = dropdownIaaSType.SelectedValue == "1" ? 20 : 125;
            //    int requestedMax = serversPerEnvironment.Sum();
            //    if (requestedMax > allowableMax)
            //    {
            //        validationMaxServersExceeded.Visible = true;
            //        txtEnvironment1Servers.Focus();
            //        Page.MaintainScrollPositionOnPostBack = false;
            //        Page.SetFocus(txtEnvironment1Servers);
            //        validationSucceeded = false;
            //    }
            //}
        }
        return validationSucceeded;
    }

    private bool IsValidNumber(string text)
    {
        int temp;
        return int.TryParse(text, out temp);
    }

    private bool SaveROM()
    {
        validationVIPRVASI.Visible = false;

        // but provide validation feedback if a field has change and
        // now contains a value that is unsupported (or an incompatible data type)
        if (!PerformValidation(true))
        {
            return false;
        }
        PopulateRomViewModelFromUI();
        Common.UpdateRom(Page, RomViewModel);
        labelLastSavedAt.Text = "ROM data last saved at " + DateTime.Now.ToLongTimeString();
        Page.MaintainScrollPositionOnPostBack = false;
        Page.SetFocus(labelTotalOneTimeCost);
        Page.MaintainScrollPositionOnPostBack = true;
        return true;
    }

    private bool PopulateEstimate()
    {
        // Note: since the only parameter to the sproc is a ROM ID, we are counting on the ROM being
        // saved before this point
        PopulateRomViewModelFromUI();

        validationVIPRVASI.Visible = false;

        // Make sure either the VIPRID or VASI has been filled in
        if (string.IsNullOrEmpty(VIPRID.Text) && string.IsNullOrEmpty(VASI.Text))
        {
            labelRequireVIPRIDVASI.Visible = false;
            validationVIPRVASI.Visible = true;
            VIPRID.Focus();
            Page.MaintainScrollPositionOnPostBack = false;
            Page.SetFocus(VIPRID);
            return false;
        }

        PopulateEstimateFromViewModel();
        txtURL.Focus();
        Page.MaintainScrollPositionOnPostBack = false;
        Page.SetFocus(txtURL);
        //Page.MaintainScrollPositionOnPostBack = true;
        return true;
    }

    private void PopulateEstimateFromViewModel()
    {
        var estimates = Common.ProvideEstimate(RomViewModel);
        labelTotalOneTimeCost.Text = estimates.OneTimeFee == 0 ?
            "---" :
            estimates.OneTimeFee.ToString("C", Common.Culture);
        labelSustainmentCostPerYear.Text = estimates.SustainmentCost == 0 ?
            "---" :
            estimates.SustainmentCost.ToString("C", Common.Culture);
        if (estimates.SustainmentCost > 0)
        {
            labelTotal.Text = "Total first-year cost (excl. future sustainment costs):";
        }
        else
        {
            labelTotal.Text = "Total first-year cost:";
        }
        labelTotalFirstYearCost.Text = (estimates.OneTimeFee == 0 && estimates.SustainmentCost == 0) ?
            "---" :
            (estimates.OneTimeFee + estimates.SustainmentCost).ToString("C", Common.Culture);
    }

    private void SyncPaaS()
    {
        if (dropdownPaasNeeded.SelectedValue == "0")
        {
            tblPaaS.Visible = false;
        }
        else
        {
            tblPaaS.Visible = true;
            if (string.IsNullOrEmpty(txtPaasDbInstances.Text))
            {
                txtPaasDbInstances.Text = "1";
            }
        }
    }

    private void SyncIaaS()
    {
        if (dropdownNeedIaaS.SelectedValue == "0")
        {
            tableIaaS.Visible = false;
        }
        else
        {
            tableIaaS.Visible = true;
        }
        SyncEnvironmentCount();
    }


    private void SyncEnvironmentCount()
    {
        // working in the stone ages... no switch on string values (!?)
        int environmentCount = 0;
        if (int.TryParse(dropdownNumberOfIaaSEnvironments.SelectedValue, out environmentCount))
        {
            if (environmentCount < 5)
            {
                Environment5.Visible = false;
            }
            if (environmentCount < 4)
            {
                Environment4.Visible = false;
            }
            if (environmentCount < 3)
            {
                Environment3.Visible = false;

            }
            if (environmentCount < 2)
            {
                Environment2.Visible = false;
            }
            if (environmentCount >= 1)
            {
                if (!Page.IsPostBack)
                {
                    Environment1Name.Text = RomViewModel.Environments[0] == null ? "PROD" : RomViewModel.Environments[0].Name;
                    txtEnvironment1Servers.Text = RomViewModel.Environments[0] == null ? "1" : RomViewModel.Environments[0].NumberOfServers.ToString();
                }
                Environment1.Visible = true;
            }
            if (environmentCount >= 2)
            {
                if (!Page.IsPostBack)
                {
                    Environment2Name.Text = RomViewModel.Environments[1] == null ? "PREPROD" : RomViewModel.Environments[1].Name;
                    txtEnvironment2Servers.Text = RomViewModel.Environments[1] == null ? "1" : RomViewModel.Environments[1].NumberOfServers.ToString();
                }
                Environment2.Visible = true;
            }
            if (environmentCount >= 3)
            {
                if (!Page.IsPostBack)
                {
                    Environment3Name.Text = RomViewModel.Environments[2] == null ? "DEVTEST" : RomViewModel.Environments[2].Name;
                    txtEnvironment3Servers.Text = RomViewModel.Environments[2] == null ? "1" : RomViewModel.Environments[2].NumberOfServers.ToString();
                }
                if (Page.IsPostBack && (RomViewModel.Environments[2] == null || string.IsNullOrEmpty(RomViewModel.Environments[2].Name)))
                {
                    Environment3Name.Text = "DEVTEST";
                    txtEnvironment3Servers.Text = "1";
                }
                Environment3.Visible = true;
            }
            if (environmentCount >= 4)
            {
                if (!Page.IsPostBack)
                {
                    Environment4Name.Text = RomViewModel.Environments[3] == null ? "" : RomViewModel.Environments[3].Name;
                    txtEnvironment4Servers.Text = RomViewModel.Environments[3] == null ? "1" : RomViewModel.Environments[3].NumberOfServers.ToString();
                }
                Environment4.Visible = true;
            }
            if (environmentCount >= 5)
            {
                if (!Page.IsPostBack)
                {
                    Environment5Name.Text = RomViewModel.Environments[4] == null ? "" : RomViewModel.Environments[4].Name;
                    txtEnvironment5Servers.Text = RomViewModel.Environments[4] == null ? "1" : RomViewModel.Environments[4].NumberOfServers.ToString();
                }
                Environment5.Visible = true;
            }
        }
    }


    #endregion



}
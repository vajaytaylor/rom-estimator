﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;

/// <summary>
/// Common functionality, such as retrieving current user identity (and other commonly-used methods)
/// </summary>
public static class Common
{
    // Set us up within the en-US culture so we display money amounts correctly, i.e. $147,265.25
    public static CultureInfo Culture = CultureInfo.CreateSpecificCulture("en-US");

    static Common()
    {
    }

    public static List<IaaSIdAndName> LoadIaaSTypes()
    {
        List<IaaSIdAndName> iaaSTypes = new List<IaaSIdAndName>();
        RomestimatorDataLayer romestimatorDataLayer = new RomestimatorDataLayer();
        var dbResult = romestimatorDataLayer.ReadIaaSTypeNames();
        var resultList = dbResult.ToList();
        foreach (var result in resultList)
        {
            iaaSTypes.Add(new IaaSIdAndName(result.ID, result.IaasTypeName));
        }
        iaaSTypes.Sort((a, b) => a.ID.CompareTo(b.ID));
        return iaaSTypes;
    }

    /// <summary>
    /// Common method to get a user identity.
    /// For now we are simply using the user's host address with the user agent appended
    /// </summary>
    /// <param name="page">The Page/Context from which the request originated</param>
    /// <returns>A string representation of the user's identity</returns>
    public static string GetUserIdentity(Page page)
    {
        // TODO: we need to find a better user identity!
        string userIdentifier = string.Format("{0}/{1}", page.Request.UserHostAddress, page.Request.UserAgent);
        return userIdentifier;
    }

    /// <summary>
    /// Takes a non-flattened result set from ReadRom and flattens it so all fields contain useful information
    /// </summary>
    /// <param name="list">A list of result rows returned from the ReadRom sproc call</param>
    /// <returns>A single ReadRom_Result that has been flattened for use</returns>
    public static ReadRomViewModel FlattenRomFromDatabase(List<ReadRom_Result> list)
    {
        ReadRomViewModel flattenedResult = new ReadRomViewModel();
        foreach (var resultRow in list)
        {
            flattenedResult.IaaSNeeded = flattenedResult.IaaSNeeded || resultRow.IaaSNeeded;
            flattenedResult.PaaSNeeded = flattenedResult.PaaSNeeded || resultRow.PaaSNeeded;
            flattenedResult.ReadOnly = flattenedResult.ReadOnly || resultRow.ReadOnly;
            if (!string.IsNullOrEmpty(resultRow.Notes))
            {
                flattenedResult.Notes = resultRow.Notes;
            }
            if (!string.IsNullOrEmpty(resultRow.VIPRID))
            {
                flattenedResult.VIPRID = resultRow.VIPRID;
            }
            if (!string.IsNullOrEmpty(resultRow.VASI))
            {
                flattenedResult.VASI = resultRow.VASI;
            }
            if (resultRow.SustainmentNeeded != false)
            {
                flattenedResult.SustainmentNeeded = resultRow.SustainmentNeeded;
            }
            if (resultRow.InstancesHighlyAvailable != null)
            {
                flattenedResult.InstancesHighlyAvailable = resultRow.InstancesHighlyAvailable.Value;
            }
            flattenedResult.ProjectName = string.IsNullOrEmpty(resultRow.ProjectName) ? flattenedResult.ProjectName : resultRow.ProjectName;
            if (resultRow.ID != Guid.Empty)
            {
                flattenedResult.ID = resultRow.ID;
            }

            if (resultRow.DateFinalized != null)
                flattenedResult.DateFinalized = resultRow.DateFinalized.Value;

            if (resultRow.QuotedOneTimePrice != null)
                flattenedResult.QuotedOneTimePrice = resultRow.QuotedOneTimePrice.Value;

            if (resultRow.QuotedSustainmentCost != null)
                flattenedResult.QuotedSustainmentCost = resultRow.QuotedSustainmentCost.Value;

            // PaaS related
            if (resultRow.DatabaseInstanceCount != null)
            {
                flattenedResult.DatabaseInstanceCount = resultRow.DatabaseInstanceCount.Value;
            }
            if (resultRow.InstancesHighlyAvailable != null)
            {
                flattenedResult.InstancesHighlyAvailable = resultRow.InstancesHighlyAvailable.Value;
            }

            // IaaS related
            if (resultRow.IaaSType != null)
            {
                flattenedResult.IaaSType = resultRow.IaaSType.Value;
            }
            if (resultRow.IaaSEnvironmentCount != 0)
            {
                flattenedResult.IaaSEnvironmentCount = resultRow.IaaSEnvironmentCount;
            }
            if (resultRow.EnvironmentIndex != null && resultRow.EnvironmentIndex.Value > 0)
            {
                flattenedResult.Environments[resultRow.EnvironmentIndex.Value - 1] = new Environment();
                flattenedResult.Environments[resultRow.EnvironmentIndex.Value - 1].Index = resultRow.EnvironmentIndex.Value;
                flattenedResult.Environments[resultRow.EnvironmentIndex.Value - 1].Name = resultRow.EnvironmentName;
                flattenedResult.Environments[resultRow.EnvironmentIndex.Value - 1].NumberOfServers = resultRow.ServerOrVMCount == null ? 0 : resultRow.ServerOrVMCount.Value;
            }
        }
        return flattenedResult;
    }

    public static FinalizeEstimate_Result FinalizeRom(Page page, ReadRomViewModel rom)
    {
        // Note: the ROM must have been saved, since the only parameter is a RomId and user who is finalizing the ROM
        RomestimatorDataLayer romestimatorDataLayer = new RomestimatorDataLayer();
        var result = romestimatorDataLayer.FinalizeEstimate(rom.ID, GetUserIdentity(page));
        var results = result.ToList();
        return results[0];
    }

    public static OneTimeAndSustainmentEstimates ProvideEstimate(ReadRomViewModel rom)
    {
        OneTimeAndSustainmentEstimates estimate = new OneTimeAndSustainmentEstimates();
        RomestimatorDataLayer romestimatorDataLayer = new RomestimatorDataLayer();
        var result = romestimatorDataLayer.ProvideEstimate(rom.ID);
        var results = result.ToList();
        estimate.OneTimeFee = results[0].OneTimeCost == null ? 0 : results[0].OneTimeCost.Value;
        estimate.SustainmentCost = results[0].SustainmentPerYear == null ? 0 : results[0].SustainmentPerYear.Value;
        return estimate;
    }

    public static void UpdateRom(Page context, ReadRomViewModel rom)
    {
        RomestimatorDataLayer romestimatorDataLayer = new RomestimatorDataLayer();
        romestimatorDataLayer.UpdateRom(
            rom.ID,
            rom.ProjectName,
            GetUserIdentity(context),
            rom.IaaSNeeded,
            rom.IaaSType,
            rom.IaaSEnvironmentCount,
            rom.PaaSNeeded,
            rom.DatabaseInstanceCount,
            rom.InstancesHighlyAvailable,
            rom.SustainmentNeeded,
            rom.Notes,
            rom.VIPRID,
            rom.VASI,
            rom.Environments[0] != null,
            rom.Environments[0] == null ? null : rom.Environments[0].Name,
            rom.Environments[0] == null ? null : (int?)rom.Environments[0].NumberOfServers,
            rom.Environments[1] != null,
            rom.Environments[1] == null ? null : rom.Environments[1].Name,
            rom.Environments[1] == null ? null : (int?)rom.Environments[1].NumberOfServers,
            rom.Environments[2] != null,
            rom.Environments[2] == null ? null : rom.Environments[2].Name,
            rom.Environments[2] == null ? null : (int?)rom.Environments[2].NumberOfServers,
            rom.Environments[3] != null,
            rom.Environments[3] == null ? null : rom.Environments[3].Name,
            rom.Environments[3] == null ? null : (int?)rom.Environments[3].NumberOfServers,
            rom.Environments[4] != null,
            rom.Environments[4] == null ? null : rom.Environments[4].Name,
            rom.Environments[4] == null ? null : (int?)rom.Environments[4].NumberOfServers);
    }
}
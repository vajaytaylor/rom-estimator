﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// ReadRomViewModel contains a "flattened" (single-row) ROM that is used for rendering the UI
/// </summary>
public class ReadRomViewModel : ReadRom_Result
{
    public Environment[] Environments = new Environment[5];
    public PaaSInfo PaaS = new PaaSInfo();

    public ReadRomViewModel() : base()
    {
    }
}
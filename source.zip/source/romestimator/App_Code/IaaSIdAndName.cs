﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// ID and Name associated with an IaaS type
/// </summary>
public class IaaSIdAndName
{
    public int ID { get; set; }
    public string Name { get; set; }

    public IaaSIdAndName()
    {        
    }

    public IaaSIdAndName(int id, string iaasTypeName)
    {
        ID = id;
        Name = iaasTypeName;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Information about PaaS
/// </summary>
public class PaaSInfo
{
    public int DatabaseNeeded { get; set; }
    public bool HighAvailability { get; set; }
    public PaaSInfo()
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// An IaaS Environment
/// </summary>
public class Environment
{
    public int Index { get; set; }
    public int NumberOfServers { get; set; }
    public string Name { get; set; }
    public Environment()
    {
    }
}
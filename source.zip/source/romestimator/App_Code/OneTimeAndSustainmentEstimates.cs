﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Stores One Time and/or Sustainment Estimates
/// </summary>
public class OneTimeAndSustainmentEstimates
{
    public decimal OneTimeFee { get; set; }
    public decimal SustainmentCost { get; set; }
    public OneTimeAndSustainmentEstimates()
    {
    }
}
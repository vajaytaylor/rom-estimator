﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnNewROM_Click(object sender, EventArgs e)
    {
        btnNewROM.Enabled = false;
        RomestimatorDataLayer romestimatorDataLayer = new RomestimatorDataLayer();
        ObjectParameter idParameter = new ObjectParameter("id", typeof(Guid));
        string userIdentifier = Common.GetUserIdentity(Page);

        ObjectResult<Guid?> romIdResult = romestimatorDataLayer.CreateRom(
            idParameter,
            "New ROM Estimate",
            userIdentifier,
            false, null, null,
            false, null, null,
            false, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
        
        List<Guid?> queryResults = romIdResult.ToList();
        if (queryResults.Count == 0 || !queryResults[0].HasValue)
        {
            throw new Exception("No ROM ID returned from CreateRom");
        }
        
        Guid romId = queryResults[0].Value;
        Page.Response.Redirect(string.Format("ROMEstimator.aspx?{0}", romId));
    }
}
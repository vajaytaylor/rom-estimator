USE romestimator
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Owen Emlen
-- Create date: 9/18/2019
-- Description:	Inserts a new ROM (which may only be partially filled-out). Returns a GUID for the new ROM that can be used
-- to gain future read/write access to the ROM
-- =============================================
CREATE PROCEDURE UpdateRom
	@RomId uniqueidentifier,
	@RomName varchar(MAX) = Unnamed, 
	@UserName varchar(MAX) = Unknown,
	@IaaSNeeded bit = 0,
	@IaaSType int = 0,
    @IaaSEnvironmentCount int = 0,
    @PaaSNeeded bit = 0,
	@PaaSDBInstances int = 0,
	@PaaSHighAvailability bit = 0,
    @SustainmentNeeded bit = 0,
	@Notes varchar(1024) = null,
	@VIPRID varchar(MAX) = null,
	@VASI varchar(MAX) = null,
    @Environment1 bit = 0,
	@Environment1Name varchar(MAX) = null,
	@Environment1ServerOrVMCount int = 0,
	@Environment2 bit = 0,
	@Environment2Name varchar(MAX) = null,
	@Environment2ServerOrVMCount int = 0,
	@Environment3 bit = 0,
	@Environment3Name varchar(MAX) = null,
	@Environment3ServerOrVMCount int = 0,
	@Environment4 bit = 0,
	@Environment4Name varchar(MAX) = null,
	@Environment4ServerOrVMCount int = 0,
	@Environment5 bit = 0,
	@Environment5Name varchar(MAX) = null,
	@Environment5ServerOrVMCount int = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Updates an existing ROM, including updates to the environments table and PaaS, based
	-- on the parameters passed in, sets the last modified date, last modified by, etc.
UPDATE [dbo].[romestimate]
           SET 
		   [ProjectName]=@RomName
           ,[LastModified]=CURRENT_TIMESTAMP
           ,[LastModifiedBy]=@UserName
           ,[IaaSNeeded]=@IaaSNeeded
           ,[IaaSType]=@IaaSType
           ,[IaaSEnvironmentCount]=@IaaSEnvironmentCount
           ,[PaaSNeeded]=@PaaSNeeded
           ,[SustainmentNeeded]=@SustainmentNeeded
		   ,[VIPRID]=@VIPRID
		   ,[VASI]=@VASI
		   ,[Notes]=@Notes
           ,[ReadOnly]=0
           WHERE ID = @RomId

		   DELETE FROM [dbo].[paas] WHERE ROMID=@RomId

		   -- now re-insert into the PaaS table, if appropriate
		   IF @PaaSNeeded = 1
		   BEGIN
			   INSERT INTO [dbo].[paas]
				   ([ROMID]
				   ,[DatabaseInstanceCount]
				   ,[InstancesHighlyAvailable])
				 VALUES
				   (@RomId,
				    @PaaSDBInstances,
  				    @PaaSHighAvailability)
		   END

		   DELETE FROM [dbo].[environments] WHERE ROMID=@RomId

			-- now insert into the environment table data, if appropriate
		   IF @IaaSEnvironmentCount > 0
		   BEGIN
				INSERT INTO [dbo].[environments]
					   ([ROMID]
					   ,[EnvironmentIndex]
					   ,[EnvironmentName]
					   ,[ServerOrVMCount])
				 VALUES
					   (@RomId
					   ,1
					   ,@Environment1Name
					   ,@Environment1ServerOrVMCount)
		   END
		   IF @IaaSEnvironmentCount > 1
		   BEGIN
				INSERT INTO [dbo].[environments]
					   ([ROMID]
					   ,[EnvironmentIndex]
					   ,[EnvironmentName]
					   ,[ServerOrVMCount])
				 VALUES
					   (@RomId
					   ,2
					   ,@Environment2Name
					   ,@Environment2ServerOrVMCount)
		   END
		   IF @IaaSEnvironmentCount > 2
		   BEGIN
				INSERT INTO [dbo].[environments]
					   ([ROMID]
					   ,[EnvironmentIndex]
					   ,[EnvironmentName]
					   ,[ServerOrVMCount])
				 VALUES
					   (@RomId
					   ,3
					   ,@Environment3Name
					   ,@Environment3ServerOrVMCount)
		   END
		   IF @IaaSEnvironmentCount > 3
		   BEGIN
				INSERT INTO [dbo].[environments]
					   ([ROMID]
					   ,[EnvironmentIndex]
					   ,[EnvironmentName]
					   ,[ServerOrVMCount])
				 VALUES
					   (@RomId
					   ,4
					   ,@Environment4Name
					   ,@Environment4ServerOrVMCount)
		   END
		   IF @IaaSEnvironmentCount > 4
		   BEGIN
				INSERT INTO [dbo].[environments]
					   ([ROMID]
					   ,[EnvironmentIndex]
					   ,[EnvironmentName]
					   ,[ServerOrVMCount])
				 VALUES
					   (@RomId
					   ,5
					   ,@Environment5Name
					   ,@Environment5ServerOrVMCount)
		   END

-- Return the GUID for the ROM
SELECT @RomId
END
GO

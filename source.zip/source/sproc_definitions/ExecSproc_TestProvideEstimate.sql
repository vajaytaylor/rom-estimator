USE [romestimator]
GO

DECLARE	@return_value int
DECLARE @AlreadyCreatedRomId uniqueidentifier = N'E143C34E-A850-4F71-BA40-461A4D327D73' -- fill in your ROM GUID here

SELECT * from romestimate WHERE ID = @AlreadyCreatedRomId

EXEC	@return_value = [dbo].[ProvideEstimate]
		@RomId = @AlreadyCreatedRomId

SELECT * from romestimate WHERE ID = @AlreadyCreatedRomId

GO

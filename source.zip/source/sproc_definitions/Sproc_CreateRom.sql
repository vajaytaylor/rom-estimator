USE romestimator
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Owen Emlen
-- Create date: 9/18/2019
-- Description:	Creates a new ROM (which may only be partially filled-out). Returns a GUID for the new ROM that can be used
-- to gain future read/write access to the ROM
-- =============================================
CREATE PROCEDURE CreateRom
	@id uniqueidentifier OUTPUT,
	@RomName varchar(MAX) = Unnamed, 
	@UserName varchar(MAX) = Unknown,
	@IaaSNeeded bit = 0,
	@IaaSType int = 0,
    @IaaSEnvironmentCount int = 0,
    @PaaSNeeded bit = 0,
	@PaaSDBInstances int = 0,
	@PaaSHighAvailability bit = 0,
    @SustainmentNeeded bit = 0,
    @Environment1 bit = 0,
	@Environment1Name varchar(MAX) = null,
	@Environment1ServerOrVMCount int = 0,
	@Environment2 bit = 0,
	@Environment2Name varchar(MAX) = null,
	@Environment2ServerOrVMCount int = 0,
	@Environment3 bit = 0,
	@Environment3Name varchar(MAX) = null,
	@Environment3ServerOrVMCount int = 0,
	@Environment4 bit = 0,
	@Environment4Name varchar(MAX) = null,
	@Environment4ServerOrVMCount int = 0,
	@Environment5 bit = 0,
	@Environment5Name varchar(MAX) = null,
	@Environment5ServerOrVMCount int = 0
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	-- SET NOCOUNT ON;

    -- Inserts a new ROM, returns the GUID used for future access to the ROM.  Also inserts into environments table, based
	-- on the parameters passed in, sets the created date, last modified date, last modified by, etc.
set @id  = NEWID()

INSERT INTO [dbo].[romestimate]
           ([ID]
		   ,[ProjectName]
           ,[DateCreated]
           ,[LastModified]
           ,[LastModifiedBy]
           ,[IaaSNeeded]
           ,[IaaSType]
           ,[IaaSEnvironmentCount]
           ,[PaaSNeeded]
           ,[SustainmentNeeded]
           ,[ReadOnly]
           ,[DateFinalized]
           ,[QuotedOneTimePrice]
           ,[QuotedSustainmentCost]
           ,[LookupIaaSUpToMaxEnvironments]
           ,[LookupIaaSUpToMaxServerCount]
           ,[LookupIaaSOneTimeFee]
           ,[LookupIaaSSustainmentCost]
           ,[LookupPaaSUptoMaxDatabases]
           ,[LookupPaaSHighAvailability]
           ,[LookupPaaSOneTimeFee]
           ,[LookupPaaSSustainmentCost])
     VALUES
           (@id,
		   @RomName,
           CURRENT_TIMESTAMP,
           CURRENT_TIMESTAMP,
           @UserName,
           @IaaSNeeded,
           @IaaSType,
           @IaaSEnvironmentCount,
           @PaaSNeeded,
           @SustainmentNeeded,
           0,
           null,
           null,
           null,
           null,
		   null,
		   null,
		   null,
		   null,
		   null,
		   null,
		   null)

		   -- now insert into the PaaS table, if appropriate
		   IF @PaaSNeeded = 1
		   BEGIN
			   INSERT INTO [dbo].[paas]
				   ([ROMID]
				   ,[DatabaseInstanceCount]
				   ,[InstancesHighlyAvailable])
				 VALUES
				   (@id,
				    @PaaSDBInstances,
  				    @PaaSHighAvailability)
		   END

			-- now insert the environment table data, if appropriate
		   IF @IaaSEnvironmentCount > 0
		   BEGIN
				INSERT INTO [dbo].[environments]
					   ([ROMID]
					   ,[EnvironmentIndex]
					   ,[EnvironmentName]
					   ,[ServerOrVMCount])
				 VALUES
					   (@id
					   ,1
					   ,@Environment1Name
					   ,@Environment1ServerOrVMCount)
		   END
		   IF @IaaSEnvironmentCount > 1
		   BEGIN
				INSERT INTO [dbo].[environments]
					   ([ROMID]
					   ,[EnvironmentIndex]
					   ,[EnvironmentName]
					   ,[ServerOrVMCount])
				 VALUES
					   (@id
					   ,2
					   ,@Environment2Name
					   ,@Environment2ServerOrVMCount)
		   END
		   IF @IaaSEnvironmentCount > 2
		   BEGIN
				INSERT INTO [dbo].[environments]
					   ([ROMID]
					   ,[EnvironmentIndex]
					   ,[EnvironmentName]
					   ,[ServerOrVMCount])
				 VALUES
					   (@id
					   ,3
					   ,@Environment3Name
					   ,@Environment3ServerOrVMCount)
		   END
		   IF @IaaSEnvironmentCount > 3
		   BEGIN
				INSERT INTO [dbo].[environments]
					   ([ROMID]
					   ,[EnvironmentIndex]
					   ,[EnvironmentName]
					   ,[ServerOrVMCount])
				 VALUES
					   (@id
					   ,4
					   ,@Environment4Name
					   ,@Environment4ServerOrVMCount)
		   END
		   IF @IaaSEnvironmentCount > 4
		   BEGIN
				INSERT INTO [dbo].[environments]
					   ([ROMID]
					   ,[EnvironmentIndex]
					   ,[EnvironmentName]
					   ,[ServerOrVMCount])
				 VALUES
					   (@id
					   ,5
					   ,@Environment5Name
					   ,@Environment5ServerOrVMCount)
		   END

-- Return the GUID for the ROM (as an output value)
SELECT @id

END
GO

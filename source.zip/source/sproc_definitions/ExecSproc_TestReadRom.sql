USE [romestimator]
GO

DECLARE	@return_value int

EXEC	@return_value = [dbo].[ReadRom]
		@RomId = N'B98FD2BA-696D-47F1-83D9-19E32277A8EE'  -- Insert Valid ROM ID here

SELECT	'Return Value' = @return_value

GO

USE [romestimator]
GO

/****** Object:  StoredProcedure [dbo].[ReadIaaSTypeNames]    Script Date: 9/26/2019 3:11:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Owen Emlen
-- Create date: 9/26/2019
-- Description:	Reads all IaaS type names from the lookup table
-- =============================================
CREATE PROCEDURE [dbo].[ReadIaaSTypeNames]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- TODO - need to read PaaS and read and flatten Environment info associated with the ROM
	SELECT * FROM [dbo].[iaastypenames]
END
GO



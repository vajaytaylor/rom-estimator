USE [romestimator]
GO

DECLARE	@return_value as int
DECLARE @RomId as uniqueidentifier

EXEC @return_value = [dbo].[CreateRom]
		@RomId output,
		@RomName = N'First ROM',
		@UserName = N'Owen',
		@IaaSNeeded = 1,
		@IaaSType = 3,
		@IaaSEnvironmentCount = 3,
		@PaaSNeeded = 1,
		@PaaSDBInstances = 5,
		@PaaSHighAvailability = 1,
		@SustainmentNeeded = 1,
		@Environment1 = 1,
		@Environment1Name = N'DEV',
		@Environment1ServerOrVMCount = 5,
		@Environment2 = 1,
		@Environment2Name = N'QA',
		@Environment2ServerOrVMCount = 10,
		@Environment3 = 1,
		@Environment3Name = N'PROD',
		@Environment3ServerOrVMCount = 15
	
SELECT * from [dbo].[romestimate] WHERE ID = @RomId
SELECT * from [dbo].[environments] WHERE ROMID = @RomId
SELECT * from [dbo].[paas] WHERE ROMID = @RomId

SELECT	'Return Value' = @return_value

GO

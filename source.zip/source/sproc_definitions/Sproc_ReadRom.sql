USE romestimator
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Owen Emlen
-- Create date: 9/19/2019
-- Description:	Reads an existing ROM (which may only be partially filled-out) by GUID. Returns IaaS environments
-- and PaaS information in a flattened structure for easy use
-- =============================================
CREATE PROCEDURE ReadRom
	@RomId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- NOTE: we are not using PIVOT to flatten our results here (I'm not exactly a SQL guru)
	-- The back-end will need to flatten PaaS and IaaS Environment info associated with the ROM
	SELECT
		 ROM.ID
		,ROM.ProjectName
		,ROM.DateCreated
		,ROM.LastModified
		,ROM.LastModifiedBy
		,ROM.IaaSNeeded
		,ROM.IaaSType
		,ROM.IaaSEnvironmentCount
		,ROM.PaaSNeeded
		,ROM.SustainmentNeeded
		,ROM.ReadOnly
		,ROM.DateFinalized
		,ROM.QuotedOneTimePrice
		,ROM.QuotedSustainmentCost
		,ROM.LookupIaaSUpToMaxEnvironments
		,ROM.LookupIaaSUpToMaxServerCount
		,ROM.LookupIaaSOneTimeFee
		,ROM.LookupIaaSSustainmentCost
		,ROM.LookupPaaSUptoMaxDatabases
		,ROM.LookupPaaSHighAvailability
		,ROM.LookupPaaSOneTimeFee
		,ROM.LookupPaaSSustainmentCost
		,ROM.Notes
		,ROM.VIPRID
		,ROM.VASI
		,ENVS.EnvironmentIndex
		,ENVS.EnvironmentName
		,ENVS.ServerOrVMCount
		,PAAS.DatabaseInstanceCount
		,PAAS.InstancesHighlyAvailable
		 FROM [dbo].[romestimate] as ROM
         LEFT OUTER JOIN [dbo].[environments] as ENVS ON ENVS.ROMID = ROM.ID
		 LEFT OUTER JOIN [dbo].[paas] AS PAAS ON PAAS.ROMID = ROM.ID
		 WHERE ROM.ID = @RomId
END
GO

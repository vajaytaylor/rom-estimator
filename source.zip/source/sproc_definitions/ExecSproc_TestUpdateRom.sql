USE [romestimator]
GO

DECLARE	@return_value int
DECLARE @id uniqueidentifier = N'E143C34E-A850-4F71-BA40-461A4D327D73' -- insert ROM id here 

EXEC	@return_value = [dbo].[UpdateRom]
		@RomId = @id,
		@RomName = N'Updated First ROM',
		@UserName = N'Owen',
		@IaaSNeeded = 1,
		@IaaSType = 2,
		@IaaSEnvironmentCount = 2,
		@PaaSNeeded = 1,
		@PaaSDBInstances = 2,
		@PaaSHighAvailability = 0,
		@SustainmentNeeded = 1,
		@Environment1 = 1,
		@Environment1Name = N'Development',
		@Environment1ServerOrVMCount = 2,
		@Environment2 = 1,
		@Environment2Name = N'Production',
		@Environment2ServerOrVMCount = 10

SELECT * from [dbo].[romestimate] WHERE ID = @id
SELECT * from [dbo].[environments] WHERE ROMID = @id
SELECT * from [dbo].[paas] WHERE ROMID = @id

SELECT	'Return Value' = @return_value

GO

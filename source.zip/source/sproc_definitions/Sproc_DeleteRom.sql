USE romestimator
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Owen Emlen
-- Create date: 9/19/2019
-- Description:	Deletes an existing ROM by GUID. 
-- =============================================
CREATE PROCEDURE DeleteRom
	@RomId uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- TODO - need to read PaaS and read and flatten Environment info associated with the ROM
	DELETE FROM [dbo].[environments] WHERE ROMID=@RomId
	DELETE FROM [dbo].[paas] WHERE ROMID=@RomId
	DELETE FROM [dbo].[romestimate] WHERE ID=@RomId

END
GO

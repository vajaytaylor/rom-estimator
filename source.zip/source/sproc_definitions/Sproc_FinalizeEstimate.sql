-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
USE romestimator
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Owen Emlen
-- Create date: 9/24/2019
-- Description:	Finalizes a rough order of magnitude (ROM) estimate and marks it as read-only. Also stamps the ROM
-- with the frozen-in-time estimate values that were used to calculate the estimate.
-- Note that the ROM values must be SAVED/Updated before calling this. i.e. the only parameter is a ROM id.
-- =============================================
CREATE PROCEDURE FinalizeEstimate
	@RomId uniqueidentifier,
	@UserIdentifier varchar(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- NOTE: we must go through a lot of the same logic to retrieve the one-time and sustainment
	-- costs, since we want to store metadata about the rows used to perform the calculations
	-- (i.e. the values we used to calculate these costs)

    -- Retrieve a rough order of magnitude (ROM) one-time and sustainment cost/year estimate (based on the values in cost 
	-- estimate lookup tables). These will be stored in the "Quoted" one-time and sustainment cost price columns
	DECLARE @EstimatedOneTimeCost money = 0
	DECLARE @EstimatedSustainmentPerYear money = 0

	-- First, retrieve the ROM
	-- Declare local variables to store the information required to produce an estimate
	DECLARE @IaaSNeeded bit
	DECLARE @IaaSType int
	DECLARE @PaaSNeeded bit
	DECLARE @SustainmentNeeded bit
	DECLARE @IaaSEnvironmentCount int 
	DECLARE @IaaSTotalServerCount int -- Total server count across all environments (since # of environments no longer plays any factor)
	DECLARE @PaaSDatabaseCount int
	DECLARE @PaaSHighAvailability bit
	
	-- Declare local variables used to store metadata about the price estimate we provided
	DECLARE @LookupIaaSUpToMaxEnvironments as int
	DECLARE @LookupIaaSUpToMaxServerCount as int
	DECLARE @LookupIaaSUpToMaxServerCountPerEnvironment as int
	DECLARE @LookupIaaSOneTimeFee as money
	DECLARE @LookupIaaSSustainmentCost as money
	DECLARE @LookupPaaSUptoMaxDatabases as int
	DECLARE @LookupPaaSHighAvailability as bit
	DECLARE @LookupPaaSOneTimeFee as money
	DECLARE @LookupPaaSSustainmentCost as money
	DECLARE @PaaSCostPerServerOneTimeFee as money = 0
	DECLARE @PaaSCostEstimateOneTimeFee as money = 0
	DECLARE @PaaSCostPerServerSustainment as money = 0
	DECLARE @PaaSCostEstimateSustainment as money = 0
	DECLARE @CostPerServerOneTimeFee as money = 0
	DECLARE @CostEstimateOneTimeFee as money = 0	
	DECLARE @CostPerServerSustainment as money = 0
	DECLARE @CostEstimateSustainment as money = 0
	
	-- Set variable values based on reading the ROM
	SELECT @IaaSNeeded = IaaSNeeded
		  ,@IaaSType = IaaSType 
		  ,@PaaSNeeded = PaaSNeeded
		  ,@SustainmentNeeded = SustainmentNeeded
		  ,@IaaSEnvironmentCount = IaaSEnvironmentCount
	FROM [dbo].[romestimate] WHERE ID=@RomId

	-- Now read the environments table to get the max number of servers per environment, if applicable
	IF @IaaSNeeded = 1
	BEGIN
		SELECT @IaaSTotalServerCount = Sum(ServerOrVMCount) FROM [dbo].[environments]
		WHERE ROMID = @RomId		
	END

	-- Now collect info about any PaaS needed, including DB count and if they need to be Highly Available
	IF @PaaSNeeded = 1
	BEGIN
		SELECT @PaaSDatabaseCount = DatabaseInstanceCount
			  ,@PaaSHighAvailability = InstancesHighlyAvailable
		FROM [dbo].[paas]
		WHERE ROMID = @RomId
	END
		
	IF @IaaSNeeded = 1
	BEGIN
		DECLARE @OneTimeFee as money = 0
		DECLARE @SustainmentCost as money = 0

		SELECT TOP 1 @OneTimeFee = IaaS_OneTimeFee
					,@SustainmentCost = IaaS_SustainmentCostPerYear
					,@LookupIaaSUpToMaxEnvironments = IaaS_UptoMaxEnvironmentCount
					,@LookupIaaSUpToMaxServerCountPerEnvironment = IaaS_UptoMaxServerCount
					,@LookupIaaSUpToMaxServerCount = IaaS_UptoMaxServerCount * IaaS_UpToMaxEnvironmentCount
					,@LookupIaaSOneTimeFee = IaaS_OneTimeFee
					,@LookupIaaSSustainmentCost = IaaS_SustainmentCostPerYear
		FROM [dbo].[iaaspriceestimatelookup]
		WHERE IaaSType = @IaaSType AND
			  -- REQUEST BY JEN: Do not take into account environment count when
			  -- providing ROMs. This doesn't seem intuitively right, but it's the marching order
			  -- for now. @IaaSEnvironmentCount <= IaaS_UpToMaxEnvironmentCount AND 
			  IaaS_UptoMaxServerCount * IaaS_UpToMaxEnvironmentCount >= @IaaSTotalServerCount 
		ORDER BY 
			  -- IaaS_UpToMaxEnvironmentCount, 
	  		  IaaS_UpToMaxServerCount * IaaS_UpToMaxEnvironmentCount

		-- special case for catching the first "bucket"		
		if @OneTimeFee = 0 BEGIN
			-- TODO: reconsider hardcoding these values
			IF @IaaSTotalServerCount < 20 BEGIN
				SELECT TOP 1 @OneTimeFee = IaaS_OneTimeFee
							,@SustainmentCost = IaaS_SustainmentCostPerYear
							,@LookupIaaSUpToMaxEnvironments = IaaS_UptoMaxEnvironmentCount
							,@LookupIaaSUpToMaxServerCountPerEnvironment = IaaS_UptoMaxServerCount
							,@LookupIaaSUpToMaxServerCount = IaaS_UptoMaxServerCount * IaaS_UpToMaxEnvironmentCount
							,@LookupIaaSOneTimeFee = IaaS_OneTimeFee
							,@LookupIaaSSustainmentCost = IaaS_SustainmentCostPerYear
				FROM [dbo].[iaaspriceestimatelookup]
				WHERE IaaSType = @IaaSType
				ORDER BY IaaS_UptoMaxServerCount * IaaS_UpToMaxEnvironmentCount
			END
			IF @IaaSTotalServerCount >= 20 BEGIN
			SELECT TOP 1 @OneTimeFee = IaaS_OneTimeFee
							,@SustainmentCost = IaaS_SustainmentCostPerYear
							,@LookupIaaSUpToMaxEnvironments = IaaS_UptoMaxEnvironmentCount
							,@LookupIaaSUpToMaxServerCountPerEnvironment = IaaS_UptoMaxServerCount
							,@LookupIaaSUpToMaxServerCount = IaaS_UptoMaxServerCount * IaaS_UpToMaxEnvironmentCount
							,@LookupIaaSOneTimeFee = IaaS_OneTimeFee
							,@LookupIaaSSustainmentCost = IaaS_SustainmentCostPerYear
				FROM [dbo].[iaaspriceestimatelookup]
				WHERE IaaSType = @IaaSType
				ORDER BY IaaS_UptoMaxServerCount * IaaS_UpToMaxEnvironmentCount DESC
			END
		END	
	
		-- this is the pricing "bucket" we'll use to calculate the per-server cost
		
		SET @CostPerServerOneTimeFee = @OneTimeFee / @LookupIaaSUpToMaxServerCount
		SET @CostEstimateOneTimeFee = @CostPerServerOneTimeFee * @IaaSTotalServerCount 
	
		SET @CostPerServerSustainment = @SustainmentCost / @LookupIaaSSustainmentCost
		SET @CostEstimateSustainment = @CostPerServerSustainment * @IaaSTotalServerCount 

		-- Add on the one time fee and possibly the sustainment cost (if sustainment needed) to the 
		-- corresponding local variables
		SET @EstimatedOneTimeCost = floor((@EstimatedOneTimeCost + @OneTimeFee + 999) / 1000) * 1000

		IF @SustainmentNeeded = 1
		BEGIN
			SET @EstimatedSustainmentPerYear = floor((@EstimatedSustainmentPerYear + @SustainmentCost + 999) / 1000) * 1000
		END
	END

	IF @PaaSNeeded = 1
	BEGIN
		DECLARE @OneTimeFeePaaS as money = 0
		DECLARE @SustainmentCostPaaS as money = 0

		IF @PaasHighAvailability = 1
		BEGIN
			-- Must select a row where HighAvailability is 1
			SELECT TOP 1 @OneTimeFeePaaS = PaaS_OneTimeFee
						,@SustainmentCostPaaS = PaaS_SustainmentCostPerYear
						,@LookupPaaSUptoMaxDatabases = PaaS_UpToMaxDatabaseCount
						,@LookupPaaSHighAvailability = PaaS_HighAvailability
						,@LookupPaaSOneTimeFee = PaaS_OneTimeFee
						,@LookupPaaSSustainmentCost = PaaS_SustainmentCostPerYear
			FROM [dbo].[paaspriceestimatelookup]
			WHERE PaaS_HighAvailability = 1 AND
	 			  PaaS_UpToMaxDatabaseCount >= @PaaSDatabaseCount
			ORDER BY PaaS_UpToMaxDatabaseCount
		END

		IF @PaaSHighAvailability = 0
		BEGIN
			-- In this case, we only care about max database count. Ignore the HighAvailability flag completely
			SELECT TOP 1 @OneTimeFeePaaS = PaaS_OneTimeFee
						,@SustainmentCostPaaS = PaaS_SustainmentCostPerYear
						,@LookupPaaSUptoMaxDatabases = PaaS_UpToMaxDatabaseCount
						,@LookupPaaSHighAvailability = PaaS_HighAvailability
						,@LookupPaaSOneTimeFee = PaaS_OneTimeFee
						,@LookupPaaSSustainmentCost = PaaS_SustainmentCostPerYear
			FROM [dbo].[paaspriceestimatelookup]
			WHERE PaaS_UpToMaxDatabaseCount >= @PaaSDatabaseCount 
			ORDER BY PaaS_UpToMaxDatabaseCount
		END

		-- special case for catching the first "bucket"
		if @OneTimeFeePaaS = 0 BEGIN
			-- TODO: reconsider hardcoding these values
			IF @PaaSDatabaseCount < 20 BEGIN
				SELECT TOP 1 @OneTimeFeePaaS = PaaS_OneTimeFee
							,@SustainmentCostPaaS = PaaS_SustainmentCostPerYear
							,@LookupPaaSUptoMaxDatabases = PaaS_UpToMaxDatabaseCount
							,@LookupPaaSOneTimeFee = PaaS_OneTimeFee
							,@LookupPaaSSustainmentCost = PaaS_SustainmentCostPerYear
				FROM [dbo].[paaspriceestimatelookup]
				ORDER BY PaaS_UpToMaxDatabaseCount
			END
			IF @PaaSDatabaseCount >= 20 BEGIN
				SELECT TOP 1 @OneTimeFeePaaS = PaaS_OneTimeFee
							,@SustainmentCostPaaS = PaaS_SustainmentCostPerYear
							,@LookupPaaSUptoMaxDatabases = PaaS_UpToMaxDatabaseCount
							,@LookupPaaSOneTimeFee = PaaS_OneTimeFee
							,@LookupPaaSSustainmentCost = PaaS_SustainmentCostPerYear
				FROM [dbo].[paaspriceestimatelookup]
				ORDER BY PaaS_UpToMaxDatabaseCount DESC
			END
		END

		-- this is the pricing "bucket" we'll use to calculate the per-server cost
		
		SET @PaaSCostPerServerOneTimeFee = @OneTimeFeePaaS / @LookupPaaSUptoMaxDatabases
		SET @PaaSCostEstimateOneTimeFee = @PaaSCostPerServerOneTimeFee * @PaaSDatabaseCount
	
		SET @PaaSCostPerServerSustainment = @SustainmentCostPaaS / @LookupPaaSUptoMaxDatabases
		SET @PaaSCostEstimateSustainment = @PaaSCostPerServerSustainment * @PaaSDatabaseCount
		
		-- Add on the one time fee and possibly the sustainment cost (if sustainment needed) to the 
		-- corresponding local variables
		SET @EstimatedOneTimeCost = floor((@EstimatedOneTimeCost + @OneTimeFeePaaS + 999) / 1000) * 1000

		IF @SustainmentNeeded = 1
		BEGIN
			SET @EstimatedSustainmentPerYear = floor((@EstimatedSustainmentPerYear + @SustainmentCostPaaS + 999) / 1000) * 1000
		END
	END

	UPDATE romestimate
	SET [romestimate].[ReadOnly] = 1
		,LastModified = CURRENT_TIMESTAMP
		,LastModifiedBy = @UserIdentifier
		,DateFinalized = CURRENT_TIMESTAMP
		,QuotedOneTimePrice = @EstimatedOneTimeCost
		,QuotedSustainmentCost = @EstimatedSustainmentPerYear
		,LookupIaaSUpToMaxEnvironments = @LookupIaaSUpToMaxEnvironments
		,LookupIaaSUpToMaxServerCount = @LookupIaaSUpToMaxServerCount
		,LookupIaaSOneTimeFee = @LookupIaaSOneTimeFee 
		,LookupIaaSSustainmentCost = @LookupIaaSSustainmentCost
		,LookupPaaSUptoMaxDatabases = @LookupPaaSUptoMaxDatabases
		,LookupPaaSHighAvailability = @LookupPaaSHighAvailability
		,LookupPaaSOneTimeFee = @LookupPaaSOneTimeFee
		,LookupPaaSSustainmentCost = @LookupPaaSSustainmentCost 
	WHERE ID = @RomId

	-- Return the GUID for the ROM along with estimated costs (one time and sustainment per year)
	SELECT @RomId as RomId, 
		   @EstimatedOneTimeCost as OneTimeCost, 
		   @EstimatedSustainmentPerYear as SustainmentPerYear,
		   @IaaSTotalServerCount AS TotalServerCountRequested, 
		   @PaaSCostPerServerOneTimeFee as PaaSOneTimeFeePerServer,
		   @PaaSCostEstimateOneTimeFee as PaaSOneTimeFee,
		   @PaaSCostPerServerSustainment as PaaSSustainmentPerServer,
		   @PaaSCostEstimateSustainment as PaaSSustainment,
		   @CostPerServerOneTimeFee as IaaSCostPerServerOneTimeFee, 
		   @CostEstimateOneTimeFee as CostEstimateOneTimeFee, 
		   @CostPerServerSustainment as CostPerServerSustainment,
		   @CostEstimateSustainment as CostEstimateSustainment 
END
GO
